# TERRAWATCH Metrics API Patch

Wires live data source readings → computed card values → terrawatch.io frontend.

---

## Data Flow

```
USGS / NOAA PORTS / NWS / ERDDAP / EPA ECHO
        ↓  (data sources patch)
  data_source_snapshots (Postgres)
        ↓
  metricsAggregator.js  ← reads latest snapshots, computes card values
        ↓
  GET /api/metrics      ← 5-min cached JSON endpoint
  GET /api/metrics/stream ← SSE push every 5min
        ↓
  terrawatch-metrics.js ← runs on terrawatch.io, updates DOM
```

---

## Card → Metric → Data Source Mapping

| Card | Metric ID | Primary Source | Secondary |
|---|---|---|---|
| HAB Oracle | `hab_oracle` | ERDDAP chlorophyll + HABSOS | NOAA PORTS salinity, USGS flow |
| Hypoxia Forecast | `hypoxia_forecast` | NOAA PORTS DO + water temp | NWS wind calm |
| Jubilee Predictor | `jubilee_predictor` | NOAA PORTS DO + wind direction | salinity |
| Water Quality Monitor | `water_quality` | NOAA PORTS Dauphin Island | USGS turbidity |
| Compound Flood | `compound_flood` | NWS precip + NOAA water level | USGS flow |
| Beach Safety Index | `beach_safety` | HAB score + DO + wave height | water temp |
| Pollution Tracker | `pollution_tracker` | USGS turbidity + EPA ECHO | seasonal flags |

---

## Files

```
server/
  services/metricsAggregator.js   ← computes all metrics from DB snapshots
  routes/metrics.js               ← Express router with cache + SSE stream
frontend/
  terrawatch-metrics.js           ← Drop into Framer custom code
SERVER_PATCH.js                   ← 3-line server.js additions
```

---

## Framer Setup

For each card value element on terrawatch.io:
1. Select the value text element (e.g. "33%", "9.2")
2. In Framer right panel → **Element** tab → **Custom Attributes**
3. Add: `data-metric` = `hab_oracle` (or the metric ID for that card)

For the subtext / label element (e.g. "Mobile Bay", "Elevated"):
1. Add: `data-metric-label` = `hab_oracle`

Paste `terrawatch-metrics.js` into:
**Site Settings → Custom Code → End of `<body>`**

Update the `API_BASE` constant to your deployed Replit URL.

---

## Local Test

```bash
curl https://your-api.replit.app/api/metrics | jq .metrics
```

Expected output:
```json
{
  "hab_oracle":        { "value": 33,  "unit": "%",      "label": "Mobile Bay" },
  "hypoxia_forecast":  { "value": 55,  "unit": "%",      "label": "Elevated"   },
  "water_quality":     { "value": 9.2, "unit": "mg/L DO","label": "Good"       },
  ...
}
```
