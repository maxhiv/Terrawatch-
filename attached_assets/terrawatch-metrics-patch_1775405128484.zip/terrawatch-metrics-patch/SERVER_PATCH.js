/**
 * TERRAWATCH — Metrics Patch: server.js additions
 * (3 lines total — add to your existing server.js)
 */

// ── BLOCK 1: Add with your existing imports ───────────────────────────────────
import metricsRouter from './server/routes/metrics.js';
import { invalidateMetricsCache } from './server/routes/metrics.js';

// ── BLOCK 2: Register route (add with your other app.use() calls) ─────────────
app.use('/api/metrics', metricsRouter);

// ── BLOCK 3: Invalidate metrics cache when data sources update ────────────────
// Add inside startPoller() callback, after pollerEvents is live:
pollerEvents.on('snapshot', () => invalidateMetricsCache());

/**
 * ── API response shape (for reference) ────────────────────────────────────────
 *
 * GET https://your-api.replit.app/api/metrics
 * {
 *   "computed_at": "2026-04-05T15:30:00Z",
 *   "cache_hit": false,
 *   "metrics": {
 *     "hab_oracle":        { "value": 33,  "unit": "%",      "label": "Mobile Bay" },
 *     "hypoxia_forecast":  { "value": 55,  "unit": "%",      "label": "Elevated"   },
 *     "jubilee_predictor": { "value": 3,   "unit": "%",      "label": "Low"        },
 *     "water_quality":     { "value": 9.2, "unit": "mg/L DO","label": "Good"       },
 *     "compound_flood":    { "value": 30,  "unit": "%",      "label": "Low"        },
 *     "beach_safety":      { "value": 100, "unit": "/ 100",  "label": "Good"       },
 *     "pollution_tracker": { "value": 2,   "unit": "/ 5",    "label": "Moderate"   }
 *   }
 * }
 */
