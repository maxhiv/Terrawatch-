/**
 * TERRAWATCH — Live Metrics Frontend Script
 *
 * Drop this in your Framer site via:
 *   Site Settings → Custom Code → <head> or <body> end
 *
 * How it works:
 *   1. Connects to SSE stream for live pushes (5min cadence)
 *   2. Falls back to polling GET /api/metrics every 5 minutes
 *   3. Updates card values by looking for data-metric="metric_id" attributes
 *
 * ── Setup in Framer ──────────────────────────────────────────────────────────
 * On each card value element, add a custom attribute in Framer:
 *   Attribute name:  data-metric
 *   Attribute value: <metric_id>   (e.g. "hab_oracle")
 *
 * On the subtext/label element (e.g. "Mobile Bay", "Elevated"):
 *   Attribute name:  data-metric-label
 *   Attribute value: <metric_id>
 *
 * Available metric IDs:
 *   hab_oracle        → value: "33", label: "Mobile Bay" (or risk level)
 *   hypoxia_forecast  → value: "55", label: "Elevated"
 *   jubilee_predictor → value: "3.2", label: "Low"
 *   water_quality     → value: "9.2", label: "mg/L DO"
 *   compound_flood    → value: "30", label: "Low"
 *   beach_safety      → value: "100", label: "/ 100 Good"
 *   pollution_tracker → value: "2", label: "Moderate"
 */

(function () {
  'use strict';

  // ── Config ────────────────────────────────────────────────────────────────
  // ⚠️ Replace with your deployed TERRAWATCH API URL
  const API_BASE   = 'https://your-terrawatch-api.replit.app';
  const METRICS_URL = `${API_BASE}/api/metrics`;
  const STREAM_URL  = `${API_BASE}/api/metrics/stream`;

  // How often to fall back to polling if SSE drops (ms)
  const POLL_INTERVAL = 5 * 60 * 1000;

  // Format a metric value for display
  function formatValue(metric) {
    if (metric.value === null || metric.value === undefined) return '—';

    // Percentage values
    if (metric.unit === '%') {
      return String(Math.round(metric.value));
    }
    // Beach safety (integer out of 100)
    if (metric.unit === '/ 100') {
      return String(metric.value);
    }
    // DO and similar — one decimal
    if (typeof metric.value === 'number') {
      return metric.value % 1 === 0
        ? String(metric.value)
        : metric.value.toFixed(1);
    }
    return String(metric.value);
  }

  // Build the subtext shown below the value (e.g. "Mobile Bay", "Elevated")
  function formatLabel(metric) {
    if (!metric.label) return '';

    // Beach safety: "/ 100 Good"
    if (metric.unit === '/ 100') return `/ 100 ${metric.label}`;

    // Percentage with context location
    if (metric.id === 'hab_oracle') return 'Mobile Bay';

    return metric.label;
  }

  // ── DOM Updater ───────────────────────────────────────────────────────────
  function applyMetrics(metricsPayload) {
    const metrics = metricsPayload?.metrics;
    if (!metrics) return;

    for (const [id, metric] of Object.entries(metrics)) {
      const valueEls = document.querySelectorAll(`[data-metric="${id}"]`);
      const labelEls = document.querySelectorAll(`[data-metric-label="${id}"]`);

      const displayValue = formatValue(metric);
      const displayLabel = formatLabel(metric);

      valueEls.forEach(el => {
        if (el.textContent !== displayValue) {
          el.textContent = displayValue;
          el.classList.add('tw-updated');
          setTimeout(() => el.classList.remove('tw-updated'), 600);
        }
      });

      labelEls.forEach(el => {
        if (el.textContent !== displayLabel) {
          el.textContent = displayLabel;
        }
      });
    }

    // Update last-refreshed timestamp if element exists
    const tsEl = document.querySelector('[data-metric="last_updated"]');
    if (tsEl && metricsPayload.computed_at) {
      const d = new Date(metricsPayload.computed_at);
      tsEl.textContent = `Updated ${d.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}`;
    }
  }

  // ── SSE Connection ────────────────────────────────────────────────────────
  let evtSource = null;
  let pollTimer  = null;

  function connectSSE() {
    if (evtSource) evtSource.close();

    evtSource = new EventSource(STREAM_URL, { withCredentials: false });

    evtSource.addEventListener('metrics', (e) => {
      try {
        const data = JSON.parse(e.data);
        applyMetrics(data);
      } catch (err) {
        console.warn('[TERRAWATCH] SSE parse error:', err);
      }
    });

    evtSource.addEventListener('error', () => {
      console.warn('[TERRAWATCH] SSE disconnected, falling back to polling');
      evtSource.close();
      startPolling();
    });
  }

  // ── Polling Fallback ──────────────────────────────────────────────────────
  async function fetchMetrics() {
    try {
      const res  = await fetch(METRICS_URL);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      applyMetrics(data);
    } catch (err) {
      console.warn('[TERRAWATCH] Metrics fetch failed:', err.message);
    }
  }

  function startPolling() {
    fetchMetrics();
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = setInterval(fetchMetrics, POLL_INTERVAL);
  }

  // ── Init ──────────────────────────────────────────────────────────────────
  function init() {
    // Try SSE first
    if (typeof EventSource !== 'undefined') {
      connectSSE();
    } else {
      // Safari fallback or environments without SSE
      startPolling();
    }
  }

  // Run on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Reconnect SSE when tab becomes visible again
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && evtSource?.readyState === EventSource.CLOSED) {
      connectSSE();
    }
  });

})();
