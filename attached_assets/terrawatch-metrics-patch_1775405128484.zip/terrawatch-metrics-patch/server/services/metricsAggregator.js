/**
 * TERRAWATCH Metrics Aggregator
 *
 * Maps raw data source readings → card display values for terrawatch.io
 *
 * Card → Data Source mapping:
 *   HAB Oracle %        ← ERDDAP chlorophyll + NOAA PORTS salinity + USGS flow + HAB bulletin
 *   Hypoxia Forecast %  ← NOAA PORTS DO + water temp + salinity stratification + NWS wind
 *   WetlandAI           ← static / future NLCD data
 *   Jubilee Predictor % ← NOAA PORTS DO + salinity + NWS calm wind conditions
 *   Water Quality DO    ← NOAA PORTS water_temp + salinity + DO (Dauphin Island station)
 *   Compound Flood %    ← NWS precip forecast + NOAA water level + USGS streamflow
 *   Beach Safety Index  ← HAB risk score + DO + beach water temp + wave height
 *   Pollution Tracker   ← EPA ECHO exceedances + USGS turbidity
 */

import { getLatestSnapshot, getRecentRiskFlags } from '../db/dataSourceQueries.js';
import { computeHABRiskScore } from '../services/dataSources/index.js';

// ── Helpers ───────────────────────────────────────────────────────────────────

function clamp(val, min, max) {
  return Math.max(min, Math.min(max, val));
}

function safeGet(obj, path, fallback = null) {
  return path.split('.').reduce((acc, key) => acc?.[key] ?? null, obj) ?? fallback;
}

/**
 * Pull latest data payloads from DB snapshots (already persisted by poller)
 */
async function getSourceData() {
  const [ports, usgs, nws, erddap, epa, gcoos, habBulletin] = await Promise.allSettled([
    getLatestSnapshot('noaa_ports'),
    getLatestSnapshot('usgs_gauges'),
    getLatestSnapshot('nws_forecast'),
    getLatestSnapshot('erddap_ocean_color'),
    getLatestSnapshot('epa_echo'),
    getLatestSnapshot('gcoos_buoys'),
    getLatestSnapshot('noaa_hab_bulletin'),
  ]);

  return {
    ports:       ports.status === 'fulfilled'       ? ports.value?.data       : null,
    usgs:        usgs.status === 'fulfilled'         ? usgs.value?.data        : null,
    nws:         nws.status === 'fulfilled'          ? nws.value?.data         : null,
    erddap:      erddap.status === 'fulfilled'       ? erddap.value?.data      : null,
    epa:         epa.status === 'fulfilled'          ? epa.value?.data         : null,
    gcoos:       gcoos.status === 'fulfilled'        ? gcoos.value?.data       : null,
    habBulletin: habBulletin.status === 'fulfilled'  ? habBulletin.value?.data : null,
  };
}

// ── Individual metric computers ───────────────────────────────────────────────

/**
 * HAB Oracle — bloom probability for Mobile Bay (0–100%)
 *
 * Signal weights:
 *   Chlorophyll-a elevation (ERDDAP)   35%
 *   Active HAB events nearby (HABSOS) 30%
 *   Salinity drop / freshwater flush  20%
 *   High upstream flow (USGS)         15%
 */
function computeHABOracle(src) {
  let score = 0;

  // Chlorophyll signal
  const chl = src.erddap?.find?.(d => d.dataset_id === 'erdMH1chla8day');
  if (chl?.stats) {
    const p90 = chl.stats.p90 ?? 0;
    if (p90 > 10)     score += 35;
    else if (p90 > 5) score += 20;
    else if (p90 > 2) score += 10;
  }

  // HAB bulletin active events
  if (src.habBulletin?.bulletin?.near_mobile_bay > 5) score += 30;
  else if (src.habBulletin?.bulletin?.near_mobile_bay > 0) score += 15;

  // Salinity at Dauphin Island (low = freshwater pulse = nutrient loading)
  const dauIsl = Array.isArray(src.ports)
    ? src.ports.find(p => p.station_id === '8735180')
    : null;
  const salinity = dauIsl?.readings?.salinity?.value;
  if (salinity !== null && salinity !== undefined) {
    if (salinity < 5)  score += 20;
    else if (salinity < 15) score += 10;
  }

  // USGS high flow
  const mobileRiver = Array.isArray(src.usgs)
    ? src.usgs.find(g => g.site_id === '02469761')
    : null;
  const flow = mobileRiver?.readings?.streamflow?.value;
  if (flow && flow > 50000) score += 15;
  else if (flow && flow > 25000) score += 8;

  return {
    value:   clamp(score, 0, 100),
    unit:    '%',
    label:   riskLabel(score),
    updated: new Date().toISOString(),
  };
}

/**
 * Hypoxia Forecast — probability of low-oxygen event in Mobile Bay (0–100%)
 *
 * Hypoxia (DO < 2 mg/L) drives jubilee events. Key precursors:
 *   Low DO at current stations
 *   High water temperature (reduces O2 solubility)
 *   Low/zero salinity gradient (poor vertical mixing)
 *   Calm winds (no mixing)
 */
function computeHypoxiaForecast(src) {
  let score = 0;

  const dauIsl = Array.isArray(src.ports)
    ? src.ports.find(p => p.station_id === '8735180')
    : null;

  // Current DO
  const doVal = dauIsl?.readings?.dissolved_o2?.value
    ?? dauIsl?.readings?.water_temp?.value; // fallback
  if (doVal !== null && doVal !== undefined) {
    // Low DO is itself a precursor to hypoxia spread
    if (doVal < 3)  score += 35;
    else if (doVal < 5) score += 20;
    else if (doVal < 7) score += 10;
  }

  // Water temperature (warm = low O2 solubility)
  const wt = dauIsl?.readings?.water_temp?.value;
  if (wt && wt > 29)  score += 25;
  else if (wt && wt > 27) score += 12;

  // Salinity stratification
  const sal = dauIsl?.readings?.salinity?.value;
  if (sal !== null && sal !== undefined) {
    if (sal < 5)  score += 20;
    else if (sal < 10) score += 10;
  }

  // Calm winds (no mixing → stratification)
  const nwsCenter = Array.isArray(src.nws)
    ? src.nws.find(p => p.point_id === 'mobile_bay_center')
    : null;
  const windSpeed = parseFloat(nwsCenter?.hourly_48h?.[0]?.wind_speed ?? '99');
  if (windSpeed < 3)  score += 20;
  else if (windSpeed < 6) score += 10;

  return {
    value:   clamp(score, 0, 100),
    unit:    '%',
    label:   hypoxiaLabel(score),
    updated: new Date().toISOString(),
  };
}

/**
 * Jubilee Predictor — probability of jubilee event within 24hr (0–100%)
 *
 * A jubilee is a mass marine animal stranding driven by hypoxic water
 * pushed to shore by specific wind conditions. Extremely local to Mobile Bay.
 *
 * Key: DO < 2 mg/L + calm/light E-SE wind + outgoing tide + warm water
 */
function computeJubileePredictor(src) {
  let score = 0;

  const dauIsl = Array.isArray(src.ports)
    ? src.ports.find(p => p.station_id === '8735180')
    : null;

  // Low DO is the primary prerequisite
  const doVal = dauIsl?.readings?.dissolved_o2?.value;
  if (doVal !== null && doVal !== undefined) {
    if (doVal < 2)  score += 40;
    else if (doVal < 4) score += 15;
    else return { value: 0, unit: '%', label: 'Low', updated: new Date().toISOString() }; // DO too high for jubilee
  }

  // Wind: E or SE direction, light speed
  const wind = dauIsl?.readings?.wind;
  if (wind) {
    const dir = wind.direction;
    const spd = wind.speed;
    // E-SE window: 90–160 degrees
    if (dir >= 80 && dir <= 170 && spd < 5)  score += 30;
    else if (dir >= 80 && dir <= 170) score += 15;
  }

  // Warm water
  const wt = dauIsl?.readings?.water_temp?.value;
  if (wt && wt > 27) score += 20;

  // Low salinity (freshwater layer trapping hypoxic water near bottom)
  const sal = dauIsl?.readings?.salinity?.value;
  if (sal !== null && sal !== undefined && sal < 10) score += 10;

  return {
    value:   clamp(score, 0, 100),
    unit:    '%',
    label:   riskLabel(score),
    updated: new Date().toISOString(),
  };
}

/**
 * Water Quality Monitor — primary field: Dissolved Oxygen (mg/L)
 * Secondary fields: salinity, water temp, turbidity
 */
function computeWaterQuality(src) {
  // Best source: NOAA PORTS Dauphin Island
  const dauIsl = Array.isArray(src.ports)
    ? src.ports.find(p => p.station_id === '8735180')
    : null;

  const doVal  = dauIsl?.readings?.dissolved_o2?.value ?? null;
  const sal    = dauIsl?.readings?.salinity?.value ?? null;
  const wt     = dauIsl?.readings?.water_temp?.value ?? null;

  // Turbidity from USGS Mobile River gauge
  const mobileG = Array.isArray(src.usgs)
    ? src.usgs.find(g => g.site_id === '02469761')
    : null;
  const turb = mobileG?.readings?.turbidity?.value ?? null;

  return {
    value:   doVal,
    unit:    'mg/L DO',
    label:   doVal ? doQualityLabel(doVal) : 'No data',
    secondary: {
      salinity:    sal ? { value: sal,  unit: 'PSU' } : null,
      water_temp:  wt  ? { value: wt,   unit: '°C'  } : null,
      turbidity:   turb ? { value: turb, unit: 'FNU' } : null,
    },
    updated: new Date().toISOString(),
  };
}

/**
 * Compound Flood — probability of coincident rainfall + storm surge + high river flow (0–100%)
 */
function computeCompoundFlood(src) {
  let score = 0;

  // NWS precip forecast
  const nwsCenter = Array.isArray(src.nws)
    ? src.nws.find(p => p.point_id === 'mobile_bay_center')
    : null;
  const maxPrecip = nwsCenter?.max_precip_chance_24h ?? 0;
  if (maxPrecip >= 80) score += 40;
  else if (maxPrecip >= 60) score += 25;
  else if (maxPrecip >= 40) score += 12;

  // NOAA PORTS water level elevation
  const dauIsl = Array.isArray(src.ports)
    ? src.ports.find(p => p.station_id === '8735180')
    : null;
  const waterLevel = dauIsl?.readings?.water_level?.value;
  if (waterLevel && waterLevel > 0.5)  score += 30;
  else if (waterLevel && waterLevel > 0.3) score += 15;

  // USGS high flow (river backing up into bay)
  const alRiver = Array.isArray(src.usgs)
    ? src.usgs.find(g => g.site_id === '02428400')
    : null;
  const flow = alRiver?.readings?.streamflow?.value;
  if (flow && flow > 60000) score += 30;
  else if (flow && flow > 35000) score += 15;

  return {
    value:   clamp(score, 0, 100),
    unit:    '%',
    label:   riskLabel(score),
    updated: new Date().toISOString(),
  };
}

/**
 * Beach Safety Index — composite safety score (0–100, higher = safer)
 * Inputs: HAB risk + DO + wave height + water temp
 */
function computeBeachSafety(src, habScore) {
  let score = 100;

  // Penalize for HAB risk
  score -= Math.round(habScore * 0.4);

  // Penalize for low DO
  const dauIsl = Array.isArray(src.ports)
    ? src.ports.find(p => p.station_id === '8735180')
    : null;
  const doVal = dauIsl?.readings?.dissolved_o2?.value;
  if (doVal !== null && doVal !== undefined) {
    if (doVal < 3) score -= 30;
    else if (doVal < 5) score -= 15;
  }

  // Penalize for high waves (Gulf buoys)
  const buoy = Array.isArray(src.gcoos)
    ? src.gcoos.find(b => b.buoy_id === '42012')
    : null;
  const waveH = buoy?.readings?.wave_height?.value;
  if (waveH && waveH > 2)  score -= 15;
  else if (waveH && waveH > 1) score -= 8;

  // Penalize for very high or low water temp (comfort + jellyfish)
  const wt = dauIsl?.readings?.water_temp?.value;
  if (wt && (wt > 32 || wt < 15)) score -= 10;

  return {
    value:   clamp(Math.round(score), 0, 100),
    unit:    '/ 100',
    label:   beachSafetyLabel(score),
    updated: new Date().toISOString(),
  };
}

/**
 * Pollution Tracker — composite pollution index
 * Inputs: EPA ECHO exceedances + USGS turbidity + NOAA PORTS data
 */
function computePollutionTracker(src) {
  let level = 0;

  // EPA ECHO
  const epaFlags = src.epa?.flags ?? [];
  if (epaFlags.includes('SPRING_LOADING_SEASON')) level += 1;
  if (epaFlags.includes('SUMMER_BLOOM_SEASON'))   level += 1;

  // Turbidity
  const mobileG = Array.isArray(src.usgs)
    ? src.usgs.find(g => g.site_id === '02469761')
    : null;
  const turb = mobileG?.readings?.turbidity?.value;
  if (turb && turb > 100) level += 3;
  else if (turb && turb > 50) level += 2;
  else if (turb && turb > 20) level += 1;

  const labels = ['Good', 'Moderate', 'Moderate', 'Elevated', 'High', 'High'];
  return {
    value:   clamp(level, 0, 5),
    unit:    '/ 5',
    label:   labels[clamp(level, 0, 5)],
    updated: new Date().toISOString(),
  };
}

// ── Master compute function ───────────────────────────────────────────────────

/**
 * Compute all dashboard card metrics in one call
 * @returns {Object} metrics keyed by card id
 */
export async function computeAllMetrics() {
  const src = await getSourceData();

  // Compute HAB oracle first (used by beach safety)
  const habOracle     = computeHABOracle(src);
  const hypoxia       = computeHypoxiaForecast(src);
  const jubilee       = computeJubileePredictor(src);
  const waterQuality  = computeWaterQuality(src);
  const compoundFlood = computeCompoundFlood(src);
  const beachSafety   = computeBeachSafety(src, habOracle.value);
  const pollution     = computePollutionTracker(src);

  return {
    computed_at: new Date().toISOString(),
    metrics: {
      hab_oracle: {
        id:          'hab_oracle',
        title:       'HAB Oracle',
        badge:       'WORLD FIRST',
        ...habOracle,
      },
      hypoxia_forecast: {
        id:          'hypoxia_forecast',
        title:       'Hypoxia Forecast',
        badge:       'WORLD FIRST',
        ...hypoxia,
      },
      jubilee_predictor: {
        id:          'jubilee_predictor',
        title:       'Jubilee Predictor',
        badge:       'LIVE',
        ...jubilee,
      },
      water_quality: {
        id:          'water_quality',
        title:       'Water Quality Monitor',
        badge:       'LIVE',
        ...waterQuality,
      },
      compound_flood: {
        id:          'compound_flood',
        title:       'Compound Flood',
        badge:       'LIVE',
        ...compoundFlood,
      },
      beach_safety: {
        id:          'beach_safety',
        title:       'Beach Safety Index',
        badge:       'LIVE',
        ...beachSafety,
      },
      pollution_tracker: {
        id:          'pollution_tracker',
        title:       'Pollution Tracker',
        badge:       'DEVELOPING',
        ...pollution,
      },
    },
  };
}

// ── Label helpers ─────────────────────────────────────────────────────────────

function riskLabel(score) {
  if (score >= 70) return 'High';
  if (score >= 40) return 'Elevated';
  if (score >= 20) return 'Moderate';
  return 'Low';
}

function hypoxiaLabel(score) {
  if (score >= 70) return 'Critical';
  if (score >= 55) return 'Elevated';
  if (score >= 30) return 'Moderate';
  return 'Low';
}

function doQualityLabel(do_val) {
  if (do_val >= 8)  return 'Excellent';
  if (do_val >= 6)  return 'Good';
  if (do_val >= 4)  return 'Fair';
  if (do_val >= 2)  return 'Poor';
  return 'Hypoxic';
}

function beachSafetyLabel(score) {
  if (score >= 80) return 'Good';
  if (score >= 60) return 'Fair';
  if (score >= 40) return 'Caution';
  return 'Warning';
}
