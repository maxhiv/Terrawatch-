# TERRAWATCH — Live Data Sources Patch v1.0

Adds 9 new live external data sources to TERRAWATCH across the full
Mobile Bay watershed continuum — upstream through the Gulf of Mexico.

---

## Sources Added

| Source | Category | Provider | API Key | Poll Interval |
|---|---|---|---|---|
| USGS Stream Gauges | UPSTREAM | USGS NWIS | ❌ Free | 15 min |
| NOAA PORTS Mobile Bay | IN_BAY | NOAA CO-OPS | ❌ Free | 6 min |
| NWS Point Forecast | ATMOSPHERIC | NOAA NWS | ❌ Free | 60 min |
| NOAA CoastWatch Ocean Color | DOWNSTREAM | NOAA ERDDAP | ❌ Free | 12 hr |
| EPA ECHO NPDES Loading | UPSTREAM | EPA ECHO | ❌ Free | Daily |
| GCOOS / NDBC Buoys | DOWNSTREAM | GCOOS/NDBC | ❌ Free | 30 min |
| NOAA HAB Bulletin | DOWNSTREAM | NOAA HABSOS | ❌ Free | 6 hr |
| AIS Vessel Traffic | HUMAN | AISHub (free) | ⚠️ Free reg | 15 min |
| USACE Dredge Notices | HUMAN | USACE Mobile | ❌ Free | Daily |

**Only one key needed:** `AISHUB_USERNAME` — free registration at aishub.net

---

## Files

```
server/
  services/dataSources/
    index.js            ← Master registry + fetchAllSources() + HAB risk scorer
    usgsGauges.js       ← USGS NWIS stream gauges (Alabama/Tombigbee/Mobile rivers)
    noaaPorts.js        ← NOAA PORTS Mobile Bay stations
    nwsForecast.js      ← NWS 48hr hourly + 7-day forecast
    erddapOceanColor.js ← NOAA CoastWatch chlorophyll-a + SST
    epaEcho.js          ← EPA ECHO NPDES nutrient loading
    gulfCoast.js        ← GCOOS buoys + NOAA HAB bulletin
    vesselTraffic.js    ← AIS vessel traffic + USACE dredge notices
  routes/
    dataSources.js      ← Express router: REST + SSE stream
  jobs/
    dataSourcePoller.js ← Background poller (per-source schedules)
  db/
    dataSourceQueries.js   ← Postgres CRUD for snapshots + risk flags
    migrations/
      003_datasources.sql  ← New tables: snapshots, risk_flag_events, health

SERVER_PATCH.js           ← 3-block patch for existing server.js
```

---

## Install

### 1. Copy files
Drop the `server/` subdirectories into your existing TERRAWATCH repo.
No existing files are modified.

### 2. Run migration
```bash
psql $DATABASE_URL -f server/db/migrations/003_datasources.sql
```

### 3. Add to server.js
See `SERVER_PATCH.js` — three small additions:
- Import `dataSourcesRouter` and `startPoller`
- Register `app.use('/api/datasources', dataSourcesRouter)`
- Call `startPoller()` inside `app.listen()`

### 4. Add Replit Secret
```
AISHUB_USERNAME = your_aishub_username
```
(All other sources work without any key)

---

## API Endpoints

| Method | Path | Description |
|---|---|---|
| GET | `/api/datasources` | Source registry + metadata |
| GET | `/api/datasources/latest` | Latest snapshot for all sources |
| GET | `/api/datasources/risk/score` | HAB risk score (0-100) + flags |
| GET | `/api/datasources/risk/flags` | Recent risk flags |
| GET | `/api/datasources/:id` | Latest snapshot for one source |
| GET | `/api/datasources/:id/history` | Historical snapshots (?hours=24) |
| POST | `/api/datasources/:id/refresh` | Manual fetch trigger |
| GET | `/api/datasources/stream` | SSE live stream of updates |

---

## HAB Risk Scoring

The patch includes a lightweight flag-based risk scorer (0–100) that runs
across all source flags in real time. Flags are weighted by their correlation
with bloom events:

| Score Range | Risk Level |
|---|---|
| 70–100 | CRITICAL |
| 45–69 | HIGH |
| 25–44 | MODERATE |
| 10–24 | LOW |
| 0–9 | MINIMAL |

This is the ops gauge — the ML model (ST-Transformer) handles deep prediction.
Wire the risk score to your alert narrative generator as an input feature.

---

## Next Steps

1. **Dauphin Island Sea Lab (DISL)** — direct partnership for in-bay sonde data
2. **NRCS Soil Moisture** — soil saturation as runoff precursor
3. **HRRR gridded model** — 3km wind for spatial bloom drift modeling
4. **AIS MarineTraffic Pro** — richer vessel metadata if AISHub is insufficient
