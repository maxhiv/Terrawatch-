/**
 * ─────────────────────────────────────────────────────────────────────────────
 * TERRAWATCH — Data Sources Patch: server.js additions
 * ─────────────────────────────────────────────────────────────────────────────
 *
 * Add the following three blocks to your existing server.js.
 * They are clearly marked with PATCH-START / PATCH-END comments.
 *
 * Where to insert:
 *   Block 1 → with your existing imports at the top of server.js
 *   Block 2 → after you create your Express `app` and before app.listen()
 *   Block 3 → inside your app.listen() callback (or just before it)
 */

// ─── BLOCK 1: Imports ────────────────────────────────────────────────────────
// Add to the top of server.js alongside your existing imports

// PATCH-START: data sources
import dataSourcesRouter from './server/routes/dataSources.js';
import { startPoller, pollerEvents } from './server/jobs/dataSourcePoller.js';
// PATCH-END: data sources


// ─── BLOCK 2: Route registration ─────────────────────────────────────────────
// Add after your other app.use() route registrations

// PATCH-START: data sources route
app.use('/api/datasources', dataSourcesRouter);
// PATCH-END: data sources route


// ─── BLOCK 3: Start poller ───────────────────────────────────────────────────
// Add inside your app.listen() callback, or just before it

// PATCH-START: start poller
app.listen(PORT, () => {
  console.log(`TERRAWATCH server running on port ${PORT}`);

  // Start background data source polling
  startPoller();

  // Optional: forward poller events to Socket.io if you use it
  // pollerEvents.on('snapshot', (snap) => io.emit('data_snapshot', snap));
  // pollerEvents.on('flags_raised', (ev) => io.emit('risk_alert', ev));
});
// PATCH-END: start poller
*/


// ─── BLOCK 4: New Replit Secret keys to add ──────────────────────────────────
/**
 * Add these to Replit Secrets (🔒 icon in sidebar):
 *
 * AISHUB_USERNAME      — Register free at aishub.net (AIS vessel traffic)
 *
 * All other sources (USGS, NOAA PORTS, NWS, ERDDAP, EPA ECHO, GCOOS, USACE)
 * are completely free with NO key required.
 */


// ─── BLOCK 5: Run DB migration ───────────────────────────────────────────────
/**
 * Run once to create the new tables:
 *
 *   psql $DATABASE_URL -f server/db/migrations/003_datasources.sql
 *
 * Or in Replit Shell:
 *   psql $REPLIT_DB_URL -f server/db/migrations/003_datasources.sql
 */
