/**
 * TERRAWATCH Data Source Poller
 * Background job that fetches all external data on per-source schedules
 * and persists results to the database.
 *
 * Architecture:
 *   - Each source has its own interval (USGS: 15min, NOAA PORTS: 6min, etc.)
 *   - Results are upserted to data_source_snapshots table
 *   - Risk flags are written to risk_flag_events for alert evaluation
 *   - The poller emits events via EventEmitter so the API route can SSE-push live
 *
 * Usage in server.js:
 *   import { startPoller, pollerEvents } from './jobs/dataSourcePoller.js';
 *   startPoller();
 *   pollerEvents.on('snapshot', (snapshot) => { io.emit('data_update', snapshot); });
 */

import { EventEmitter } from 'events';
import { DATA_SOURCES, fetchAllSources, computeHABRiskScore } from '../services/dataSources/index.js';
import { saveSnapshot, saveRiskFlags, getLatestSnapshot } from '../db/dataSourceQueries.js';

export const pollerEvents = new EventEmitter();

const intervals = new Map(); // source_id → NodeJS interval handle
let isRunning   = false;

/**
 * Start all polling intervals
 */
export function startPoller() {
  if (isRunning) return;
  isRunning = true;

  console.log('[Poller] Starting TERRAWATCH data source poller...');

  for (const source of DATA_SOURCES) {
    // Run immediately on startup, then on interval
    runSourceFetch(source);

    const handle = setInterval(
      () => runSourceFetch(source),
      source.poll_interval_min * 60 * 1000
    );

    intervals.set(source.id, handle);
    console.log(`[Poller] Scheduled: ${source.label} — every ${source.poll_interval_min}min`);
  }

  // Emit full snapshot every 5 minutes (for dashboard refresh)
  setInterval(emitFullSnapshot, 5 * 60 * 1000);
}

/**
 * Stop all polling intervals
 */
export function stopPoller() {
  for (const [id, handle] of intervals) {
    clearInterval(handle);
    console.log(`[Poller] Stopped: ${id}`);
  }
  intervals.clear();
  isRunning = false;
}

/**
 * Fetch a single source, persist, and emit events
 */
async function runSourceFetch(source) {
  const t0 = Date.now();

  try {
    const data     = await source.fetch();
    const elapsed  = Date.now() - t0;

    const snapshot = {
      source_id:   source.id,
      label:       source.label,
      category:    source.category,
      timestamp:   new Date().toISOString(),
      elapsed_ms:  elapsed,
      data,
      flags:       extractFlags(data),
    };

    // Persist to DB (non-blocking)
    saveSnapshot(snapshot).catch(e =>
      console.error(`[Poller] DB save error (${source.id}):`, e.message)
    );

    // Save risk flag events if any flags raised
    if (snapshot.flags.length > 0) {
      saveRiskFlags(snapshot.flags.map(f => ({
        source_id:  source.id,
        flag:       f.flag,
        context:    f.context ?? null,
        timestamp:  snapshot.timestamp,
      }))).catch(e =>
        console.error(`[Poller] Risk flag save error (${source.id}):`, e.message)
      );
    }

    // Emit per-source event
    pollerEvents.emit('source_update', snapshot);

    if (snapshot.flags.length > 0) {
      pollerEvents.emit('flags_raised', { source_id: source.id, flags: snapshot.flags });
    }

    console.log(`[Poller] ✓ ${source.label} (${elapsed}ms) — ${snapshot.flags.length} flags`);

  } catch (err) {
    console.error(`[Poller] ✗ ${source.label}: ${err.message}`);
    pollerEvents.emit('source_error', { source_id: source.id, error: err.message });
  }
}

/**
 * Emit a consolidated snapshot across all sources
 * Used for dashboard full-refresh
 */
async function emitFullSnapshot() {
  try {
    const snapshot = await fetchAllSources();
    pollerEvents.emit('snapshot', snapshot);
  } catch (err) {
    console.error('[Poller] Full snapshot error:', err.message);
  }
}

/**
 * Manually trigger a fetch for a specific source (used by /api/datasources/refresh)
 */
export async function triggerSourceRefresh(sourceId) {
  const source = DATA_SOURCES.find(s => s.id === sourceId);
  if (!source) throw new Error(`Unknown source: ${sourceId}`);
  await runSourceFetch(source);
}

/**
 * Extract all flags from a data result (handles nested structures)
 */
function extractFlags(data) {
  const flags = [];

  if (!data) return flags;

  // Direct flags array
  if (Array.isArray(data.flags)) {
    flags.push(...data.flags.map(f => ({ flag: f, context: null })));
  }

  // Array of station/buoy results, each with flags
  if (Array.isArray(data)) {
    for (const item of data) {
      if (Array.isArray(item.flags)) {
        flags.push(...item.flags.map(f => ({
          flag:    f,
          context: item.name ?? item.station_id ?? item.buoy_id ?? null,
        })));
      }
    }
  }

  return flags;
}
