-- TERRAWATCH Data Sources Patch — DB Migration
-- Run once: psql $DATABASE_URL -f 003_datasources.sql
-- (or execute via your existing migration runner)

-- ── Snapshots table ───────────────────────────────────────────────────────────
-- Stores latest data for each source. JSONB allows flexible per-source schemas.
CREATE TABLE IF NOT EXISTS data_source_snapshots (
    id          BIGSERIAL PRIMARY KEY,
    source_id   TEXT        NOT NULL,
    label       TEXT,
    category    TEXT,           -- UPSTREAM | IN_BAY | DOWNSTREAM | ATMOSPHERIC | HUMAN | SATELLITE
    timestamp   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    elapsed_ms  INTEGER,
    data        JSONB       NOT NULL DEFAULT '{}',
    flags       JSONB       NOT NULL DEFAULT '[]',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_dss_source_time ON data_source_snapshots (source_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_dss_category    ON data_source_snapshots (category);
CREATE INDEX IF NOT EXISTS idx_dss_flags       ON data_source_snapshots USING GIN (flags);

-- ── Risk flag events ──────────────────────────────────────────────────────────
-- Append-only log of all risk flags raised across sources.
-- Used for alert evaluation, HAB risk scoring, and audit trail.
CREATE TABLE IF NOT EXISTS risk_flag_events (
    id          BIGSERIAL PRIMARY KEY,
    source_id   TEXT        NOT NULL,
    flag        TEXT        NOT NULL,
    context     TEXT,           -- station name, buoy ID, etc.
    timestamp   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_rfe_timestamp  ON risk_flag_events (timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_rfe_flag       ON risk_flag_events (flag);
CREATE INDEX IF NOT EXISTS idx_rfe_source     ON risk_flag_events (source_id, timestamp DESC);

-- ── Source health tracking ────────────────────────────────────────────────────
-- Tracks last successful fetch time and error streaks per source.
CREATE TABLE IF NOT EXISTS data_source_health (
    source_id         TEXT        PRIMARY KEY,
    last_success_at   TIMESTAMPTZ,
    last_error_at     TIMESTAMPTZ,
    last_error_msg    TEXT,
    consecutive_errors INTEGER     NOT NULL DEFAULT 0,
    total_fetches     BIGINT       NOT NULL DEFAULT 0,
    total_errors      BIGINT       NOT NULL DEFAULT 0,
    avg_elapsed_ms    INTEGER,
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── Convenience view: latest snapshot per source ──────────────────────────────
CREATE OR REPLACE VIEW latest_source_snapshots AS
    SELECT DISTINCT ON (source_id)
        source_id,
        label,
        category,
        timestamp,
        elapsed_ms,
        data,
        flags
    FROM data_source_snapshots
    ORDER BY source_id, timestamp DESC;

-- ── Convenience view: active risk flags (last 6 hours) ───────────────────────
CREATE OR REPLACE VIEW active_risk_flags AS
    SELECT
        source_id,
        flag,
        context,
        timestamp,
        NOW() - timestamp AS age
    FROM risk_flag_events
    WHERE timestamp > NOW() - INTERVAL '6 hours'
    ORDER BY timestamp DESC;
