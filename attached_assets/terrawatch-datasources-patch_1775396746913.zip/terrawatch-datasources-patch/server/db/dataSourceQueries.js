/**
 * Data Source DB Queries
 * Assumes a `pool` or `query` function exported from your existing db client.
 * Adjust the import path to match your TERRAWATCH DB setup.
 */

// ⚠️ Adjust this import to match your existing TERRAWATCH db client path
import { query } from './client.js';

/**
 * Upsert a source snapshot — keep last N per source to control storage
 */
export async function saveSnapshot(snapshot) {
  await query(
    `INSERT INTO data_source_snapshots
       (source_id, label, category, timestamp, elapsed_ms, data, flags)
     VALUES ($1, $2, $3, $4, $5, $6, $7)`,
    [
      snapshot.source_id,
      snapshot.label,
      snapshot.category,
      snapshot.timestamp,
      snapshot.elapsed_ms,
      JSON.stringify(snapshot.data),
      JSON.stringify(snapshot.flags),
    ]
  );

  // Prune to last 200 rows per source
  await query(
    `DELETE FROM data_source_snapshots
     WHERE source_id = $1
       AND id NOT IN (
         SELECT id FROM data_source_snapshots
         WHERE source_id = $1
         ORDER BY timestamp DESC
         LIMIT 200
       )`,
    [snapshot.source_id]
  );
}

/**
 * Get latest snapshot for each source
 */
export async function getLatestSnapshots() {
  const { rows } = await query(
    `SELECT DISTINCT ON (source_id)
       source_id, label, category, timestamp, elapsed_ms, data, flags
     FROM data_source_snapshots
     ORDER BY source_id, timestamp DESC`
  );
  return rows;
}

/**
 * Get latest snapshot for a specific source
 */
export async function getLatestSnapshot(sourceId) {
  const { rows } = await query(
    `SELECT source_id, label, category, timestamp, elapsed_ms, data, flags
     FROM data_source_snapshots
     WHERE source_id = $1
     ORDER BY timestamp DESC
     LIMIT 1`,
    [sourceId]
  );
  return rows[0] ?? null;
}

/**
 * Get snapshot history for a source (for trend charts)
 */
export async function getSnapshotHistory(sourceId, hours = 24) {
  const since = new Date(Date.now() - hours * 3600 * 1000).toISOString();
  const { rows } = await query(
    `SELECT timestamp, data, flags
     FROM data_source_snapshots
     WHERE source_id = $1 AND timestamp > $2
     ORDER BY timestamp ASC`,
    [sourceId, since]
  );
  return rows;
}

/**
 * Save risk flag events (for alert history and audit trail)
 */
export async function saveRiskFlags(flags) {
  if (!flags.length) return;

  const placeholders = flags.map((_, i) => `($${i*4+1}, $${i*4+2}, $${i*4+3}, $${i*4+4})`).join(',');
  const values       = flags.flatMap(f => [f.source_id, f.flag, f.context, f.timestamp]);

  await query(
    `INSERT INTO risk_flag_events (source_id, flag, context, timestamp)
     VALUES ${placeholders}`,
    values
  );
}

/**
 * Get recent risk flags (last 24 hours) for alert evaluation
 */
export async function getRecentRiskFlags(hours = 24) {
  const since = new Date(Date.now() - hours * 3600 * 1000).toISOString();
  const { rows } = await query(
    `SELECT source_id, flag, context, timestamp
     FROM risk_flag_events
     WHERE timestamp > $1
     ORDER BY timestamp DESC`,
    [since]
  );
  return rows;
}

/**
 * Get composite HAB risk score over last N hours
 */
export async function getHABRiskHistory(hours = 72) {
  const since = new Date(Date.now() - hours * 3600 * 1000).toISOString();
  const { rows } = await query(
    `SELECT
       date_trunc('hour', timestamp::timestamptz) AS hour,
       COUNT(*) AS flag_count,
       array_agg(DISTINCT flag) AS flags
     FROM risk_flag_events
     WHERE timestamp > $1
     GROUP BY 1
     ORDER BY 1 ASC`,
    [since]
  );
  return rows;
}
