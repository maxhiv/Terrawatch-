/**
 * NOAA NWS Point Forecast API
 * Endpoint: https://api.weather.gov — FREE, no key required
 *
 * Fetches hourly + 7-day forecasts for key Mobile Bay area grid points.
 * Wind data drives bloom drift modeling. Precip data drives upstream
 * nutrient loading forecasts (rain event → watershed runoff pulse).
 *
 * Grid points:
 *   MOB/42,58 — Mobile Bay center (30.4°N, 87.9°W)
 *   MOB/36,54 — Dauphin Island / bay mouth
 *   MOB/50,65 — Upper bay / Mobile delta
 */

import fetch from 'node-fetch';

const NWS_BASE = 'https://api.weather.gov';

// NWS office + grid coordinates for the Mobile Bay area
// Get these by hitting: https://api.weather.gov/points/{lat},{lon}
const FORECAST_POINTS = [
  {
    id:       'mobile_bay_center',
    label:    'Mobile Bay Center',
    lat:      30.45,
    lon:      -87.93,
    position: { lat: 30.45, lon: -87.93 },
  },
  {
    id:       'dauphin_island',
    label:    'Dauphin Island / Bay Mouth',
    lat:      30.25,
    lon:      -88.08,
    position: { lat: 30.25, lon: -88.08 },
  },
  {
    id:       'mobile_delta',
    label:    'Mobile Delta / Upper Bay',
    lat:      30.72,
    lon:      -88.00,
    position: { lat: 30.72, lon: -88.00 },
  },
];

const NWS_HEADERS = {
  'User-Agent': 'TERRAWATCH-HAB-Monitor/1.0 (contact@terrawatch.io)',
  'Accept': 'application/geo+json',
};

/**
 * Resolve a lat/lon to a NWS grid forecast URL
 * NWS requires this 2-step resolution: points → gridpoint URL
 */
async function resolveGridURL(lat, lon) {
  const res = await fetch(`${NWS_BASE}/points/${lat},${lon}`, {
    headers: NWS_HEADERS,
    signal: AbortSignal.timeout(10000),
  });
  if (!res.ok) throw new Error(`NWS points HTTP ${res.status}`);
  const json = await res.json();
  return {
    hourlyURL: json.properties?.forecastHourly,
    weeklyURL: json.properties?.forecast,
    gridId:    json.properties?.gridId,
    gridX:     json.properties?.gridX,
    gridY:     json.properties?.gridY,
    timezone:  json.properties?.timeZone,
  };
}

/**
 * Fetch hourly forecast for next 48 hours from a resolved URL
 */
async function fetchHourlyForecast(hourlyURL) {
  const res = await fetch(hourlyURL, {
    headers: NWS_HEADERS,
    signal: AbortSignal.timeout(15000),
  });
  if (!res.ok) throw new Error(`NWS hourly HTTP ${res.status}`);
  const json = await res.json();
  const periods = json.properties?.periods ?? [];

  // Return next 48 hours
  return periods.slice(0, 48).map(p => ({
    start_time:          p.startTime,
    end_time:            p.endTime,
    temp_f:              p.temperature,
    temp_unit:           p.temperatureUnit,
    wind_speed:          p.windSpeed,
    wind_direction:      p.windDirection,
    wind_dir_degrees:    compassToDegrees(p.windDirection),
    precip_chance:       p.probabilityOfPrecipitation?.value ?? 0,
    short_forecast:      p.shortForecast,
    icon:                p.icon,
    is_daytime:          p.isDaytime,
  }));
}

/**
 * Fetch 7-day forecast and extract precip + wind summary
 */
async function fetchWeeklyForecast(weeklyURL) {
  const res = await fetch(weeklyURL, {
    headers: NWS_HEADERS,
    signal: AbortSignal.timeout(15000),
  });
  if (!res.ok) throw new Error(`NWS weekly HTTP ${res.status}`);
  const json = await res.json();
  const periods = json.properties?.periods ?? [];

  return periods.slice(0, 14).map(p => ({
    name:            p.name,
    start_time:      p.startTime,
    temp_f:          p.temperature,
    wind_speed:      p.windSpeed,
    wind_direction:  p.windDirection,
    precip_chance:   p.probabilityOfPrecipitation?.value ?? 0,
    detailed:        p.detailedForecast,
    short_forecast:  p.shortForecast,
    is_daytime:      p.isDaytime,
  }));
}

/**
 * Main fetch: all forecast points, hourly + weekly
 */
export async function fetchNWSForecasts() {
  const results = [];

  for (const point of FORECAST_POINTS) {
    try {
      const grid = await resolveGridURL(point.lat, point.lon);

      const [hourly, weekly] = await Promise.allSettled([
        fetchHourlyForecast(grid.hourlyURL),
        fetchWeeklyForecast(grid.weeklyURL),
      ]);

      // Compute wind bloom-risk flags from next 24hr
      const next24h = hourly.status === 'fulfilled' ? hourly.value.slice(0, 24) : [];
      const flags = [];

      // High precip chance → upstream loading event likely
      const maxPrecip = Math.max(...next24h.map(h => h.precip_chance), 0);
      if (maxPrecip >= 70) flags.push('RAIN_EVENT_LIKELY');
      if (maxPrecip >= 50) flags.push('PRECIP_ELEVATED');

      // Wind direction analysis for bloom surface drift
      const windDirs = next24h
        .map(h => h.wind_dir_degrees)
        .filter(d => d !== null);
      const dominantDir = windDirs.length ? average(windDirs) : null;
      if (dominantDir !== null) {
        // South/southwest winds push bay bloom toward shoreline
        if (dominantDir >= 160 && dominantDir <= 250) flags.push('ONSHORE_WIND');
        // North/northeast winds push surface water down-bay
        if (dominantDir >= 0 && dominantDir <= 70)   flags.push('DOWN_BAY_WIND');
      }

      results.push({
        source:       'noaa_nws',
        point_id:     point.id,
        label:        point.label,
        position:     point.position,
        grid:         { id: grid.gridId, x: grid.gridX, y: grid.gridY },
        timezone:     grid.timezone,
        timestamp:    new Date().toISOString(),
        hourly_48h:   hourly.status === 'fulfilled' ? hourly.value : [],
        weekly_14d:   weekly.status === 'fulfilled' ? weekly.value : [],
        flags,
        max_precip_chance_24h: maxPrecip,
        dominant_wind_dir:     dominantDir,
      });

    } catch (err) {
      results.push({
        source:   'noaa_nws',
        point_id: point.id,
        label:    point.label,
        error:    err.message,
        timestamp: new Date().toISOString(),
      });
    }
  }

  return results;
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function compassToDegrees(dir) {
  const map = {
    N: 0, NNE: 22.5, NE: 45, ENE: 67.5,
    E: 90, ESE: 112.5, SE: 135, SSE: 157.5,
    S: 180, SSW: 202.5, SW: 225, WSW: 247.5,
    W: 270, WNW: 292.5, NW: 315, NNW: 337.5,
  };
  return map[dir] ?? null;
}

function average(arr) {
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}
