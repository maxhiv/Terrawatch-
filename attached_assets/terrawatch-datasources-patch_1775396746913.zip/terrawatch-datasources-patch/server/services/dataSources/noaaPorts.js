/**
 * NOAA PORTS — Physical Oceanographic Real-Time System
 * Mobile Bay Station: 8735180 (Dauphin Island)
 * Secondary:         8735391 (Dog River, upper bay)
 * API: https://api.tidesandcurrents.noaa.gov — FREE, no key required
 *
 * Products fetched:
 *   water_level    — Bay level + tidal state (surge detection)
 *   salinity       — Stratification proxy; low salinity = high freshwater inflow
 *   water_temp     — Surface water temperature (bloom kinetics)
 *   wind           — Local wind speed/direction (bloom drift, mixing)
 *   air_temp       — Air temperature
 *   currents       — Surface current speed + direction (when available)
 *
 * Why this matters for TERRAWATCH:
 *   Salinity drop + high flow + warm water = stratification + nutrient flush = HAB trigger
 *   Wind shift → bloom surface drift direction
 *   Low DO + high water temp + low salinity = jubilee event precursor
 */

import fetch from 'node-fetch';

const PORTS_BASE = 'https://api.tidesandcurrents.noaa.gov/api/prod/datagetter';

const STATIONS = [
  { id: '8735180', name: 'Dauphin Island',         role: 'bay_mouth',  position: { lat: 30.251, lon: -88.075 } },
  { id: '8735391', name: 'Dog River Bridge',        role: 'upper_bay',  position: { lat: 30.576, lon: -88.089 } },
  { id: '8736897', name: 'Coden',                   role: 'west_shore', position: { lat: 30.376, lon: -88.230 } },
];

const PRODUCTS = [
  'water_level',
  'salinity',
  'water_temperature',
  'wind',
  'air_temperature',
];

/**
 * Fetch latest hour of data for a given station + product
 */
async function fetchProduct(stationId, product) {
  const now     = new Date();
  const endDt   = formatNOAADate(now);
  const startDt = formatNOAADate(new Date(now - 60 * 60 * 1000)); // 1 hour back

  const params = new URLSearchParams({
    begin_date:  startDt,
    end_date:    endDt,
    station:     stationId,
    product,
    datum:       'MLLW',
    time_zone:   'gmt',
    interval:    '6min',
    units:       'metric',
    application: 'TERRAWATCH',
    format:      'json',
  });

  const res = await fetch(`${PORTS_BASE}?${params}`, {
    signal: AbortSignal.timeout(12000),
  });

  if (!res.ok) return null;

  const json = await res.json();
  if (json.error) return null;

  const data = json.data ?? [];
  return data.length ? data[data.length - 1] : null;
}

/**
 * Fetch currents — different endpoint schema
 */
async function fetchCurrents(stationId) {
  const now     = new Date();
  const endDt   = formatNOAADate(now);
  const startDt = formatNOAADate(new Date(now - 60 * 60 * 1000));

  const params = new URLSearchParams({
    begin_date:  startDt,
    end_date:    endDt,
    station:     stationId,
    product:     'currents',
    time_zone:   'gmt',
    interval:    '6min',
    units:       'metric',
    application: 'TERRAWATCH',
    format:      'json',
  });

  try {
    const res = await fetch(`${PORTS_BASE}?${params}`, { signal: AbortSignal.timeout(12000) });
    if (!res.ok) return null;
    const json = await res.json();
    const data = json.data ?? [];
    return data.length ? data[data.length - 1] : null;
  } catch {
    return null;
  }
}

/**
 * Fetch all products for all PORTS stations
 * @returns {Promise<Array>} Station readings with all available products
 */
export async function fetchNOAAPORTS() {
  const results = [];

  for (const station of STATIONS) {
    const reading = {
      source:    'noaa_ports',
      station_id: station.id,
      name:      station.name,
      role:      station.role,
      position:  station.position,
      timestamp: new Date().toISOString(),
      readings:  {},
      flags:     [],
    };

    // Fetch all products concurrently per station
    const [waterLevel, salinity, waterTemp, wind, airTemp, currents] = await Promise.allSettled([
      fetchProduct(station.id, 'water_level'),
      fetchProduct(station.id, 'salinity'),
      fetchProduct(station.id, 'water_temperature'),
      fetchProduct(station.id, 'wind'),
      fetchProduct(station.id, 'air_temperature'),
      fetchCurrents(station.id),
    ]);

    if (waterLevel.status === 'fulfilled' && waterLevel.value) {
      const v = parseFloat(waterLevel.value.v);
      reading.readings.water_level = { value: v, unit: 'm', label: 'Water Level (MLLW)', timestamp: waterLevel.value.t };
    }

    if (salinity.status === 'fulfilled' && salinity.value) {
      const v = parseFloat(salinity.value.s ?? salinity.value.v);
      reading.readings.salinity = { value: v, unit: 'PSU', label: 'Salinity', timestamp: salinity.value.t };
      if (v < 5)  reading.flags.push('LOW_SALINITY');    // major freshwater intrusion
      if (v < 10) reading.flags.push('REDUCED_SALINITY'); // stratification risk
    }

    if (waterTemp.status === 'fulfilled' && waterTemp.value) {
      const v = parseFloat(waterTemp.value.v);
      reading.readings.water_temp = { value: v, unit: '°C', label: 'Water Temperature', timestamp: waterTemp.value.t };
      if (v > 28) reading.flags.push('WARM_WATER'); // bloom-favorable temp
    }

    if (wind.status === 'fulfilled' && wind.value) {
      reading.readings.wind = {
        speed:     parseFloat(wind.value.s),
        direction: parseFloat(wind.value.d),
        gust:      parseFloat(wind.value.g),
        unit:      'm/s',
        label:     'Wind',
        timestamp: wind.value.t,
      };
    }

    if (airTemp.status === 'fulfilled' && airTemp.value) {
      reading.readings.air_temp = { value: parseFloat(airTemp.value.v), unit: '°C', label: 'Air Temperature' };
    }

    if (currents.status === 'fulfilled' && currents.value) {
      reading.readings.currents = {
        speed:     parseFloat(currents.value.s),
        direction: parseFloat(currents.value.d),
        unit:      'cm/s',
        label:     'Surface Current',
      };
    }

    results.push(reading);
  }

  return results;
}

/**
 * Format date for NOAA API: YYYYMMDD HH:MM
 */
function formatNOAADate(date) {
  const pad = n => String(n).padStart(2, '0');
  return `${date.getUTCFullYear()}${pad(date.getUTCMonth() + 1)}${pad(date.getUTCDate())} ${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}`;
}
