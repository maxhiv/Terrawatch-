/**
 * NOAA CoastWatch ERDDAP — Ocean Color / Chlorophyll-a
 * Endpoint: https://coastwatch.pfeg.noaa.gov/erddap — FREE, no key required
 *
 * Datasets:
 *   erdMH1chla8day  — MODIS Aqua 8-day composite chlorophyll-a (4km)
 *   erdVH2018chla8day — VIIRS SNPP 8-day composite chlorophyll-a (4km)
 *   erdMH1sstd8day  — MODIS SST 8-day (sea surface temperature)
 *
 * Query region: Northern Gulf of Mexico / Mobile Bay approaches
 *   Lat: 29.5°N → 31.5°N
 *   Lon: -89.5°W → -87.0°W
 *
 * Why this matters:
 *   Chlorophyll-a concentration is the direct optical proxy for phytoplankton
 *   density (including HAB species). Combined with SST, this gives the offshore
 *   bloom extent and intensity that feeds TERRAWATCH's ML prediction engine.
 */

import fetch from 'node-fetch';

const ERDDAP_BASE = 'https://coastwatch.pfeg.noaa.gov/erddap/griddap';

// Mobile Bay / Northern Gulf bounding box
const BBOX = {
  minLat:  29.5,
  maxLat:  31.5,
  minLon: -89.5,
  maxLon: -87.0,
};

const DATASETS = [
  {
    id:       'erdMH1chla8day',
    variable: 'chlorophyll',
    label:    'MODIS Aqua Chlorophyll-a (8-day)',
    unit:     'mg/m³',
    sensor:   'MODIS_Aqua',
  },
  {
    id:       'erdVH2018chla8day',
    variable: 'chla',
    label:    'VIIRS SNPP Chlorophyll-a (8-day)',
    unit:     'mg/m³',
    sensor:   'VIIRS_SNPP',
  },
  {
    id:       'erdMH1sstd8day',
    variable: 'sst',
    label:    'MODIS Sea Surface Temperature (8-day)',
    unit:     '°C',
    sensor:   'MODIS_Aqua',
  },
];

/**
 * Build ERDDAP griddap CSV query URL
 * Returns the latest available 8-day composite for the bounding box
 */
function buildERDDAPUrl(dataset, variable, timeStr) {
  // ERDDAP griddap query format:
  // /datasetId.csvp?variable[(time)][(lat1):(lat2)][(lon1):(lon2)]
  const latRange = `[${BBOX.minLat}:1:${BBOX.maxLat}]`;
  const lonRange = `[${BBOX.minLon}:1:${BBOX.maxLon}]`;
  const timeRange = timeStr ? `[(${timeStr})]` : '[last]';

  return `${ERDDAP_BASE}/${dataset}.csvp?${variable}${timeRange}${latRange}${lonRange}`;
}

/**
 * Parse ERDDAP CSV response into a grid summary
 * Returns statistics rather than the full grid (too large for in-memory use)
 */
function parseERDDAPCSV(csvText, variable) {
  const lines = csvText.trim().split('\n');
  if (lines.length < 2) return null;

  // Skip header row
  const values = [];
  for (let i = 1; i < lines.length; i++) {
    const parts = lines[i].split(',');
    const val = parseFloat(parts[parts.length - 1]);
    if (!isNaN(val) && val > 0) values.push(val);
  }

  if (!values.length) return null;

  values.sort((a, b) => a - b);
  const n   = values.length;
  const sum = values.reduce((a, b) => a + b, 0);

  return {
    count:   n,
    min:     values[0],
    max:     values[n - 1],
    mean:    sum / n,
    median:  values[Math.floor(n / 2)],
    p75:     values[Math.floor(n * 0.75)],
    p90:     values[Math.floor(n * 0.90)],
    p95:     values[Math.floor(n * 0.95)],
  };
}

/**
 * Fetch latest ocean color data for all datasets
 */
export async function fetchOceanColor() {
  const results = [];

  for (const ds of DATASETS) {
    try {
      const url = buildERDDAPUrl(ds.id, ds.variable, null);

      const res = await fetch(url, {
        headers: { 'User-Agent': 'TERRAWATCH-HAB-Monitor/1.0 (contact@terrawatch.io)' },
        signal: AbortSignal.timeout(30000), // ERDDAP can be slow
      });

      if (!res.ok) {
        results.push({
          source:    'noaa_erddap',
          dataset_id: ds.id,
          label:     ds.label,
          sensor:    ds.sensor,
          variable:  ds.variable,
          unit:      ds.unit,
          error:     `HTTP ${res.status}`,
          timestamp: new Date().toISOString(),
        });
        continue;
      }

      const csvText = await res.text();
      const stats   = parseERDDAPCSV(csvText, ds.variable);

      // Flag elevated chlorophyll concentrations
      const flags = [];
      if (stats && ds.variable !== 'sst') {
        if (stats.p90 > 10)  flags.push('HIGH_CHLOROPHYLL');  // bloom-level
        if (stats.p90 > 5)   flags.push('ELEVATED_CHLOROPHYLL');
        if (stats.mean > 3)  flags.push('ABOVE_AVERAGE_CHLOROPHYLL');
      }
      if (stats && ds.variable === 'sst') {
        if (stats.mean > 29) flags.push('WARM_SST');
        if (stats.mean > 27) flags.push('ELEVATED_SST');
      }

      results.push({
        source:     'noaa_erddap',
        dataset_id: ds.id,
        label:      ds.label,
        sensor:     ds.sensor,
        variable:   ds.variable,
        unit:       ds.unit,
        bbox:       BBOX,
        stats,
        flags,
        timestamp:  new Date().toISOString(),
      });

    } catch (err) {
      results.push({
        source:     'noaa_erddap',
        dataset_id: ds.id,
        label:      ds.label,
        error:      err.message,
        timestamp:  new Date().toISOString(),
      });
    }
  }

  return results;
}

/**
 * Fetch time series of basin-averaged chlorophyll for the last N composites
 * Used to build the temporal feature vector for ML prediction
 */
export async function fetchChlorophyllTimeSeries(datasetId = 'erdMH1chla8day', nComposites = 8) {
  // ERDDAP time slice: last N composites
  const url = `${ERDDAP_BASE}/${datasetId}.csvp?chlorophyll[last-${nComposites}:1:last][${BBOX.minLat}:1:${BBOX.maxLat}][${BBOX.minLon}:1:${BBOX.maxLon}]`;

  const res = await fetch(url, {
    headers: { 'User-Agent': 'TERRAWATCH-HAB-Monitor/1.0' },
    signal: AbortSignal.timeout(60000),
  });

  if (!res.ok) throw new Error(`ERDDAP time series HTTP ${res.status}`);

  const csvText = await res.text();
  const lines = csvText.trim().split('\n').slice(1);

  // Group by timestamp, compute basin mean per composite
  const timeMap = {};
  for (const line of lines) {
    const parts = line.split(',');
    if (parts.length < 4) continue;
    const t   = parts[0];
    const val = parseFloat(parts[3]);
    if (!isNaN(val) && val > 0) {
      if (!timeMap[t]) timeMap[t] = [];
      timeMap[t].push(val);
    }
  }

  return Object.entries(timeMap).map(([t, vals]) => ({
    timestamp: t,
    mean_chl:  vals.reduce((a, b) => a + b, 0) / vals.length,
    n_pixels:  vals.length,
  })).sort((a, b) => a.timestamp.localeCompare(b.timestamp));
}
