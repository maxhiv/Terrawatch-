/**
 * NOAA Gulf of Mexico HAB Bulletin + GCOOS Data Aggregator
 *
 * Sources:
 *   1. NOAA Gulf of Mexico HAB Bulletin — weekly forecast bulletin
 *      https://coastwatch.noaa.gov/hab/gomex.html (parsed) or NOAA RSS
 *   2. GCOOS ERDDAP — Gulf of Mexico coastal observing buoys
 *      https://data.gcoos.org/erddap
 *   3. NOAA HABSOS — HAB historical occurrence database
 *      https://coastalscience.noaa.gov/research/stressor-impacts-mitigation/hab-monitoring-system/
 *
 * All free, no key required.
 *
 * The NOAA HAB Bulletin is ground truth — it uses satellite + ship + model fusion
 * and is published weekly specifically for the Gulf of Mexico. Ingesting it gives
 * TERRAWATCH a calibration signal and a baseline to beat with local predictions.
 */

import fetch from 'node-fetch';

const GCOOS_ERDDAP = 'https://data.gcoos.org/erddap';

// GCOOS buoy platforms near Mobile Bay / Northern Gulf shelf
// These are the NDBC/GCOOS buoys with water quality sensors closest to the bay
const GCOOS_BUOYS = [
  { id: '42012', name: 'Orange Beach, AL',    position: { lat: 30.065, lon: -87.552 } },
  { id: '42039', name: 'Gulf Shores, AL',     position: { lat: 28.787, lon: -86.006 } },
  { id: 'DPIA1', name: 'Dauphin Island',      position: { lat: 30.250, lon: -88.075 } },
  { id: 'MBPA1', name: 'Middle Bay Platform', position: { lat: 30.432, lon: -88.001 } },
];

const NDBC_BASE = 'https://www.ndbc.noaa.gov';

/**
 * Fetch latest NDBC/GCOOS buoy observations
 * NDBC serves real-time data in text format — free, no auth
 */
export async function fetchGCOOSBuoys() {
  const results = [];

  for (const buoy of GCOOS_BUOYS) {
    try {
      // NDBC latest observation endpoint
      const url = `${NDBC_BASE}/data/realtime2/${buoy.id}.txt`;

      const res = await fetch(url, {
        headers: { 'User-Agent': 'TERRAWATCH-HAB-Monitor/1.0 (contact@terrawatch.io)' },
        signal: AbortSignal.timeout(10000),
      });

      if (!res.ok) {
        results.push({ ...buoy, source: 'ndbc_gcoos', error: `HTTP ${res.status}` });
        continue;
      }

      const text = await res.text();
      const parsed = parseNDBCData(text);

      results.push({
        source:    'ndbc_gcoos',
        buoy_id:   buoy.id,
        name:      buoy.name,
        position:  buoy.position,
        timestamp: parsed.timestamp,
        readings:  parsed.readings,
        flags:     computeBuoyFlags(parsed.readings),
      });

    } catch (err) {
      results.push({ ...buoy, source: 'ndbc_gcoos', error: err.message });
    }
  }

  return results;
}

/**
 * Parse NDBC realtime2 text format
 * Header: #YY  MM DD hh mm WDIR WSPD GST  WVHT   DPD   APD MWD   PRES  ATMP  WTMP  DEWP  VIS PTDY  TIDE
 */
function parseNDBCData(text) {
  const lines = text.trim().split('\n').filter(l => !l.startsWith('#'));
  if (!lines.length) return { timestamp: null, readings: {} };

  // First non-comment line = most recent observation
  const parts = lines[0].trim().split(/\s+/);

  // NDBC format: YY MM DD hh mm WDIR WSPD GST WVHT DPD APD MWD PRES ATMP WTMP DEWP VIS PTDY TIDE
  const [yr, mo, dd, hh, mm, wdir, wspd, gst, wvht, dpd, apd, mwd, pres, atmp, wtmp] = parts;

  const safeFloat = v => {
    const n = parseFloat(v);
    return (isNaN(n) || n === 99 || n === 999 || n === 9999) ? null : n;
  };

  const timestamp = yr ? `20${yr}-${mo}-${dd}T${hh}:${mm}:00Z` : null;

  return {
    timestamp,
    readings: {
      wind_dir:    { value: safeFloat(wdir), unit: '°',    label: 'Wind Direction' },
      wind_speed:  { value: safeFloat(wspd), unit: 'm/s',  label: 'Wind Speed' },
      wind_gust:   { value: safeFloat(gst),  unit: 'm/s',  label: 'Wind Gust' },
      wave_height: { value: safeFloat(wvht), unit: 'm',    label: 'Wave Height' },
      wave_period: { value: safeFloat(dpd),  unit: 's',    label: 'Dominant Wave Period' },
      pressure:    { value: safeFloat(pres), unit: 'hPa',  label: 'Barometric Pressure' },
      air_temp:    { value: safeFloat(atmp), unit: '°C',   label: 'Air Temperature' },
      water_temp:  { value: safeFloat(wtmp), unit: '°C',   label: 'Water Temperature' },
    },
  };
}

function computeBuoyFlags(readings) {
  const flags = [];
  const wt = readings.water_temp?.value;
  const ws = readings.wind_speed?.value;
  if (wt && wt > 28) flags.push('WARM_GULF_WATER');
  if (ws && ws > 10) flags.push('HIGH_WIND');
  if (ws && ws < 3)  flags.push('CALM_CONDITIONS'); // bloom-favorable
  return flags;
}

/**
 * Fetch NOAA HAB Bulletin for Gulf of Mexico
 * NOAA publishes this as a JSON feed at HABSOS
 * Fallback: RSS/HTML scrape of the coastwatch bulletin
 */
export async function fetchNOAAHABBulletin() {
  const result = {
    source:    'noaa_hab_bulletin',
    region:    'Gulf of Mexico',
    timestamp: new Date().toISOString(),
    bulletin:  null,
    flags:     [],
    error:     null,
  };

  try {
    // NOAA HABSOS GeoJSON endpoint — confirmed public
    const url = 'https://coastalscience.noaa.gov/habsos/download.aspx?format=json&region=GOM&ndays=30';

    const res = await fetch(url, {
      headers: { 'User-Agent': 'TERRAWATCH-HAB-Monitor/1.0 (contact@terrawatch.io)' },
      signal: AbortSignal.timeout(20000),
    });

    if (res.ok) {
      const json = await res.json();
      const features = json.features ?? [];

      // Filter to Mobile Bay / Northern Gulf region
      const nearBay = features.filter(f => {
        const [lon, lat] = f.geometry?.coordinates ?? [];
        return lat >= 29 && lat <= 32 && lon >= -90 && lon <= -87;
      });

      result.bulletin = {
        total_observations: features.length,
        near_mobile_bay:    nearBay.length,
        recent_events:      nearBay.slice(0, 10).map(f => ({
          lat:      f.geometry.coordinates[1],
          lon:      f.geometry.coordinates[0],
          species:  f.properties?.GENUS,
          category: f.properties?.CATEGORY,
          date:     f.properties?.SAMPLE_DATE,
          cell_conc: f.properties?.CELLCONC,
        })),
      };

      if (nearBay.length > 0) result.flags.push('ACTIVE_HAB_EVENTS_NEARBY');
      if (nearBay.length > 5) result.flags.push('ELEVATED_HAB_ACTIVITY');
    }

  } catch (err) {
    result.error = err.message;
  }

  return result;
}

/**
 * Composite function: fetch all external bay/gulf data
 */
export async function fetchGulfCoastSources() {
  const [buoys, bulletin] = await Promise.allSettled([
    fetchGCOOSBuoys(),
    fetchNOAAHABBulletin(),
  ]);

  return {
    buoys:    buoys.status === 'fulfilled'    ? buoys.value    : { error: buoys.reason?.message },
    bulletin: bulletin.status === 'fulfilled' ? bulletin.value : { error: bulletin.reason?.message },
  };
}
